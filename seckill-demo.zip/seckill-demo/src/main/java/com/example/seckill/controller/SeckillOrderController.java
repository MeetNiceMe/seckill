package com.example.seckill.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhoubin
 *
 */
@Controller
@RequestMapping("/seckillOrder")
public class SeckillOrderController {

}
